import experiment_1
import experiment_2


if __name__ == "__main__":
    #experiment_1.experiment_1_KMeans()
    #experiment_1.experiment_1_DBSCAN()
    #experiment_2.experiment_2_KMeans()
    experiment_2.experiment_2_DBSCAN()
    #experiment_2.experiment_2_KMeans_IRIS_AND_OTHERS()
    #experiment_2.experiment_2_DBSCAN_IRIS_AND_OTHERS()